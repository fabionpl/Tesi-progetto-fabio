from odoo import models, fields, api



class clinicalPatient(models.Model):
    _name = 'clinical.patient'
    #_inherit = 'hr.employee'
    _inherit = ['mail.thread','mail.activity.mixin']


    #patient = fields.Many2one('clinical.code', track_visibility='onchange')
    fiscalcode = fields.Char(string="Codice fiscale", size=16)
    name = fields.Char(string="Nome del paziente")
    surname = fields.Char(string="Cognome del paziente")
    #place = fields.Many2one('res.city.it.code.distinct','Luogo di nascita', track_visibility='onchange')
    place = fields.Char(string="Città")
    province = fields.Many2one('res.country.state', 'Provincia', track_visibility='onchange')
    date = fields.Date("Data di nascita")
    number = fields.Char(string="Numero di telefono", size=10)
    Sintomi = fields.Many2many('clinical.category', track_visibility='onchange')
    sesso = fields.Selection([
        ('M', 'Maschio'),
        ('F', 'Femmina')]
    )
    phone = fields.Char(string="Numero di cellulare", size=10)
    email = fields.Char(string="Email")
    malato = fields.Boolean("Malato")
    cura = fields.Boolean("In cura")
    category_parent_id = fields.Many2one('category.parent', string='Categoria patologia', track_visibility='always')
    category_child_id = fields.Many2one('category.child', string='Patologia specifica', track_visibility='always')
    image = fields.Binary()
    luogo = fields.Many2one('res.city.it.code.distinct', 'Luogo di nascita', track_visibility='always')
    provincia = fields.Many2one('res.country.state', 'Provincia di nascita', track_visibility='always')
    street = fields.Char(string="Via")
    zip = fields.Char(string="CAP")
    mobile_whatsapp_link = fields.Html(compute='compute_mobile_whatsapp_link')

    @api.onchange('fiscalcode')
    def onchange_fiscalcode(self):
        partner_model = self.env['res.partner']
        for record in self:
            if record.fiscalcode:
                partner = partner_model.search(
                    [
                        ('fiscalcode', '!=', False),
                        ('fiscalcode', '=', record.fiscalcode)
                    ], limit=1)
                record.name = partner.firstname
                record.surname = partner.lastname
                record.number = partner.phone
                record.place = partner.city
                record.province = partner.state_id
                record.date = partner.birthdate_date
                record.sesso = partner.gender
                record.phone = partner.mobile
                record.email = partner.email
                record.image = partner.image
                record.luogo = partner.luogo
                record.provincia = partner.provincia
                record.street = partner.street
                record.zip = partner.zip


    @api.onchange('phone')
    def compute_mobile_whatsapp_link(self):
        for record in self:
            body = ''

            if record.phone:
                body = """
                <a target="_blank" href="https://api.whatsapp.com/send?l=it&phone=%s&text=Ciao, sei stato aggiunto alla nostra lista">
                    <i class="fa fa-whatsapp"/> <span class="hidden-lg hidden-xl">Send via WhatsApp</span>
                </a>
                """ % record.phone
            record.mobile_whatsapp_link = body



    @api.multi
    def do_toggle_button(self):                     #in seguito sono riportati i metodi per definire dei bottoni di prova
        for todo in self:
            todo.malato = not todo.malato


    @api.multi
    def do_clear_done(self):
        dones = self.search([
            ('malato', '=', True)
        ])

        dones.write({
            'cura': True
        })

    @api.multi
    def toggle_button(self):
        for todo in self:
            todo.cura = not todo.cura
    #company_id = fields.Many2one('res.company', string='Clinica', index=True,
                                 #default=lambda self: self.env.user.company_id)
    #coach_id = fields.Many2one('hr.employee', 'Coach')
    #user_id = fields.Many2one('res.users', 'User', related='resource_id.user_id', store=True, readonly=False)
    #name = self._fields['name']._desription_selection(self.env)


    #def compute_default_value(self):
        #return dict(self._fields['name'].selection).get(self.type)
        #self._fields['your_field']._desription_selection(self.env)

    #class clinicalDoctor(models.Model):
#    _name = 'clinical.doctor'
#
#    name = field.Char(string="Nome del medico")
#    surname = fields.Char(string="Cognome del medico")