from odoo import models, fields, api



class clinicalCategory(models.Model):
    _name = 'clinical.category'

    #image = fields.Binary()
    #malato = fields.Selection(
        #string="Malato cronico",
        #selection=[('S', 'Si'), ('N', 'No')])
    #cura = fields.Boolean("In cura")
    name = fields.Char(string='Sintomi')
    description = fields.Html(string="Descrizione")


class CategoriaParent(models.Model):
    _name = 'category.parent'

    name = fields.Char(string="Nome")


class CategoriaChild(models.Model):
    _name = 'category.child'

    name = fields.Char(string="Nome")
    category_parent_id = fields.Many2one('category.parent', string='Categoria Parent', required=True, track_visibility='always')

