Il modulo patient_managment è a tutti gli effetti uno schedario pazienti con metodi integrati per azioni specifiche

I due mouduli luogo_di_nascita e provincia_di_nascita estendono il modello res_partner in modo da avere la giusta corrispondenza con i campi del modello Patient

Il file python definisce un bot per messaggi preimpostati
Si ricordi di importare il prefisso numerico
